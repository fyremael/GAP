"""
Minimal skeleton for Gap-Protected Transformer experiments.

This is intentionally lightweight. It demonstrates the interfaces and diagnostics;
production code should replace dense projectors with sparse or implicit solvers.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Callable

import torch
import torch.nn as nn


@dataclass
class DiagnosticOutput:
    y: torch.Tensor
    metrics: Dict[str, torch.Tensor]


class DenseConstraintOperator(nn.Module):
    """A simple dense constraint operator A: V -> W."""

    def __init__(self, A: torch.Tensor):
        super().__init__()
        if A.ndim != 2:
            raise ValueError("A must be a 2D tensor.")
        self.register_buffer("A", A)

    def apply(self, x: torch.Tensor) -> torch.Tensor:
        # x: (..., dim_v); A: (dim_w, dim_v)
        return x @ self.A.T

    def adjoint(self, y: torch.Tensor) -> torch.Tensor:
        # y: (..., dim_w)
        return y @ self.A


class DenseKernelProjector(nn.Module):
    """Orthogonal projector onto ker(A) using SVD.

    For large systems, replace with sparse Hodge/Poisson solves or cached nullspace bases.
    """

    def __init__(self, A: torch.Tensor, rtol: float = 1e-6):
        super().__init__()
        if A.ndim != 2:
            raise ValueError("A must be a 2D tensor.")
        # P_K = I - A^+ A
        A_pinv = torch.linalg.pinv(A, rtol=rtol)
        dim_v = A.shape[1]
        P = torch.eye(dim_v, device=A.device, dtype=A.dtype) - A_pinv @ A
        # Symmetrize to reduce numerical noise.
        P = 0.5 * (P + P.T)
        self.register_buffer("P", P)
        self.constraint = DenseConstraintOperator(A)

    def project(self, x: torch.Tensor) -> torch.Tensor:
        return x @ self.P.T

    def complement(self, x: torch.Tensor) -> torch.Tensor:
        return x - self.project(x)

    def leakage(self, x: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
        ax = self.constraint.apply(x)
        return torch.linalg.norm(ax) / (torch.linalg.norm(x) + eps)

    def protected_energy(self, x: torch.Tensor) -> torch.Tensor:
        return torch.mean(self.project(x) ** 2)

    def complement_energy(self, x: torch.Tensor) -> torch.Tensor:
        return torch.mean(self.complement(x) ** 2)


class TinyResidualMLP(nn.Module):
    def __init__(self, dim: int, hidden_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ProjectedResidualBlock(nn.Module):
    """x_next = P_K(x + Phi(x))."""

    def __init__(self, projector: DenseKernelProjector, learned_block: nn.Module):
        super().__init__()
        self.projector = projector
        self.learned_block = learned_block

    def forward(self, x: torch.Tensor, return_metrics: bool = False):
        y_raw = x + self.learned_block(x)
        y = self.projector.project(y_raw)
        if not return_metrics:
            return y
        return DiagnosticOutput(
            y=y,
            metrics={
                "leakage_in": self.projector.leakage(x).detach(),
                "leakage_raw": self.projector.leakage(y_raw).detach(),
                "leakage_out": self.projector.leakage(y).detach(),
                "protected_energy": self.projector.protected_energy(y).detach(),
                "complement_energy": self.projector.complement_energy(y).detach(),
            },
        )


class SplitProtectedBlock(nn.Module):
    """Protected channel is transported separately; complement is learned."""

    def __init__(
        self,
        projector: DenseKernelProjector,
        complement_block: nn.Module,
        protected_transport: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.projector = projector
        self.complement_block = complement_block
        self.protected_transport = protected_transport or nn.Identity()

    def forward(self, x: torch.Tensor, return_metrics: bool = False):
        x_k = self.projector.project(x)
        x_p = self.projector.complement(x)
        y_k = self.protected_transport(x_k)
        y_p = self.complement_block(x_p)
        y = y_k + y_p
        if not return_metrics:
            return y
        cross_leak = self.projector.leakage(y_k)
        return DiagnosticOutput(
            y=y,
            metrics={
                "leakage_in": self.projector.leakage(x).detach(),
                "leakage_protected_channel": cross_leak.detach(),
                "protected_energy": torch.mean(y_k ** 2).detach(),
                "complement_energy": torch.mean(y_p ** 2).detach(),
            },
        )


def commutator_error(Ac: torch.Tensor, R: torch.Tensor, RA: torch.Tensor, Af: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """Return normalized ||A_c R - R_A A_f||_F."""
    left = Ac @ R
    right = RA @ Af
    denom = torch.linalg.norm(left) + torch.linalg.norm(right) + eps
    return torch.linalg.norm(left - right) / denom


def demo() -> Dict[str, float]:
    torch.manual_seed(0)
    dim_v = 8
    dim_w = 3
    A = torch.randn(dim_w, dim_v)
    projector = DenseKernelProjector(A)
    block = ProjectedResidualBlock(projector, TinyResidualMLP(dim_v, 32))
    x = torch.randn(4, dim_v)
    out = block(x, return_metrics=True)
    return {k: float(v.cpu()) for k, v in out.metrics.items()}


if __name__ == "__main__":
    print(demo())
