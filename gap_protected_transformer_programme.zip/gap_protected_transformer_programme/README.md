# Gap-Protected Transformers
## Compatible Multigrid Principles for Structure-Preserving Attention and MoE

This package is the first programme-grade specification for the Gap-Protected Transformer line.

Core thesis:

> Our work builds on divergence-free networks, Hodge neural operators, structure-preserving operator learning, and neural multigrid. We contribute a unified transformer/MoE formulation, a diagnostic suite, and an ablation framework for protected-mode leakage and gap preservation.

The disciplined claim is not that Transformers automatically inherit multigrid guarantees. The disciplined claim is that we can import the algebraic etiquette that makes compatible multigrid reliable: preserve the protected subspace, commute across hierarchy changes, learn on the complement, and audit the spectral gap.

Recommended first paper title:

**Gap-Protected Neural Operators: Compatible Multigrid Principles for Structure-Preserving Attention**

Secondary house-style title:

**The Modes Beneath the Motion: Gap-Protected Transformers as Learned Compatible Smoothers**

Package contents:

- `PAPER_SPINE.md`: abstract, contribution claims, theorem targets, and narrative structure.
- `MODEL_SPEC.md`: mathematical formulation of protected-mode transport and complement learning.
- `DIAGNOSTIC_SUITE.md`: leakage, commutator, spectral, pseudospectral, and rollout metrics.
- `ABLATION_MATRIX.md`: exact ablations required to validate utility.
- `RUN_MATRIX.md`: first experiment matrix across PDE, graph-flow, and MoE diagnostic settings.
- `CODEX_HANDOFF.md`: implementation brief and module boundaries.
- `RELATED_WORK_BOUNDARY.md`: novelty-safe related-work framing.
- `FIGURE_CAPTIONS.md`: captions matching the generated conceptual diagrams.
- `src/gap_transformer_skeleton.py`: minimal PyTorch-style skeleton for protected projectors and diagnostics.

Immediate execution target:

1. Build a grid/graph Hodge projector.
2. Implement a projected attention block.
3. Log protected-mode leakage and commutator error at every layer.
4. Compare against vanilla Transformer, soft-PINN penalty, hard-output projection, and full compatible hierarchy.
5. Evaluate under long rollout and resolution transfer.
