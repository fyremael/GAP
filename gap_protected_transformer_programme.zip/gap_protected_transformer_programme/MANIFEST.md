# Manifest

- `ABLATION_MATRIX.md`
- `CODEX_HANDOFF.md`
- `DIAGNOSTIC_SUITE.md`
- `FIGURE_CAPTIONS.md`
- `MODEL_SPEC.md`
- `PAPER_SPINE.md`
- `README.md`
- `RELATED_WORK_BOUNDARY.md`
- `RUN_MATRIX.md`
- `src/gap_transformer_skeleton.py`
